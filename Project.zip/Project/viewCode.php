<?php
$connection=new MongoClient();
$db=$connection->project;
$S_firstName=null;
$S_lastName=null;
$marks=null;
$S_rollNo=null;
$code=null;
$Result_Id=null;
$S_email=null;
if($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['comment'])) {
        $Result_Id=$_POST['Result_Id'];
        $S_firstName=$_POST['S_firstName'];
        $S_lastName=$_POST['S_lastName'];
        $marks=$_POST['marks'];
        $S_rollNo=$_POST['S_rollNo'];
        $code=$_POST['code'];
        $S_email=$_POST['S_email'];
}
?>
<html>
    <head>
        <link href="editorCSS.css" rel="stylesheet" type="text/css"/>
        <link href="CodeMirror/lib/codemirror.css" rel="stylesheet" type="text/css"/>
        <script src="CodeMirror/addon/edit/matchbrackets.js"></script>
        <link href="CodeMirror/addon/hint/show-hint.css" rel="stylesheet" type="text/css"/>
        <script src="CodeMirror/addon/hint/show-hint.js"></script>
        <script src="CodeMirror/mode/clike/clike.js"></script>
        <script src="CodeMirror/lib/codemirror.js"></script>
        <script src="jquery-3.1.1.min.js" type="text/javascript"></script>
    </head>
    <body style="margin-left:15%;margin-right: 15%;">
        <?php
            $S_firstName=$_POST['S_firstName'];
            $S_lastName=$_POST['S_lastName'];
            $S_rollNo=$_POST['S_rollNo'];
            $code=$_POST['code'];
            $marks=$_POST['marks'];
            $Result_Id=$_POST['Result_Id'];
            $S_email=$_POST['S_email'];
        ?>
        <div class="nav">
            <h1 style="text-align: center;">MIT</h1>
            <hr>
            <a href="teacherHomePage.php" style="text-decoration: none;font-size: 30px;margin-left: 41%;">Home</a>
            <a href="teacherResults.php" style="text-decoration: none;text-align:  center; font-size: 30px;">Results</a>
            <a href="home.php" style="text-decoration: none;text-align: center; font-size: 30px;">Logout</a>
            <hr>
        </div>
        <h3>Name</h3>
        <?php echo "$S_firstName $S_lastName";?>
        <h3>Roll No</h3>
        <?php echo "$S_rollNo";?>
        <h3>Marks Obtained</h3>
        <?php echo $marks;?>
        <h3>Code</h3>
        <div id="editor_block">
            <textarea id="c-code"><?php echo $code;?></textarea>
            <script>
                var editor = CodeMirror.fromTextArea(document.getElementById("c-code"), {
                    lineNumbers: true,
                    matchBrackets: true,
                    mode: "text/x-csrc"
                });
            </script>
        </div>
        <?php
        $connection=new MongoClient();
        $db=$connection->project;
        ?>
        <form action="<?php echo $_SERVER['PHP_SELF'];?>" method="post">
            <h3>Feedback</h3>
            <textarea rows ="8" cols="80" name="comment" id="comment"></textarea>
            <br>
            <input type="submit" name="Feedback" value="Feedback" class="button">
            <?php
                    echo "<input type='hidden' name='S_firstName' value='$S_firstName'>";
                    echo "<input type='hidden' name='S_lastName' value='$S_lastName'>";
                    echo "<input type='hidden' name='S_rollNo' value='$S_rollNo'>";
                    echo "<input type='hidden' name='marks' value='$marks'>";
                    echo "<input type='hidden' name='code' value='$code'>";
                    echo "<input type='hidden' name='Result_Id' value='$Result_Id'>";
                    echo "<input type='hidden' name='S_email' value='$S_email'>";
            ?>
        </form>
    </body>
    </head>
</html>
<?php
    if (isset($_POST['Feedback']))
    {
        $feedback=$_POST['comment'];
        $coll=$db->$Result_Id;
        $query=array('S_email'=>$S_email);
        $cursor=$coll->find($query);
        if(count($cursor)!=0){
            $query=$coll->update(array('S_email'=>$S_email),array('$set'=>array('feedback'=>$feedback)));
            echo "<script type='text/javascript'>alert('Feedback sent sucessfully');</script>";
        }
    }
?>