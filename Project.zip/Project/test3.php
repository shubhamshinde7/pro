<html>
    <body>
<?php
    $connection=new MongoClient();
    $db=$connection->project;
    $Result_Id="Result_58a346214a181277083c9869";
    $collection=$db->$Result_Id;
    $query=$collection->find();
    $array=array();
    foreach ($query as $doc) {
        $array[]=$doc['code'];
    }
    plagirism($array);
?>
    </body>
</html>
<?php
function plagirism($array)
{
    for($i=0;$i<count($array);$i++){
        $j_max=0;
       // $token1=array();
        $token1= token($array[$i]);
        for($j=0;$j<count($array);$j++){
           // $token2=array();
            $token2= token($array[$j]);
            $jaccard=0;
            $same=0;
            $distinct=0;
            $flag=0;
            if($i!=$j){
                for($m=0;$m<count($token1)-3;$m=$m+4){
                    $flag=0;
                    for($n=0;$n<count($token2)-3;$n=$n+4){
                        //echo "<br/>same=$same distinct =$distinct ";
                        if(strcmp($token1[$m],$token2[$n])==0 && strcmp($token1[$m+1],$token2[$n+1])==0 && strcmp($token1[$m+2],$token2[$n+2])==0 && strcmp($token1[$m+3],$token2[$n+3])==0){
                            $same=$same+1;
                            $flag=1;
                            break;
                        }
                        if($flag==0){
                            $distinct=$distinct+1;
                        }
                    }
                }
                $jaccard=($same/ count($token2))*100;
                echo "<br/>same=$same distinct=$distinct i=$i j=$j jaccard=$jaccard";
                if($jaccard>$j_max){
                    $j_max=$jaccard;
                }
            }
        }
        echo "<br/>jaccard=".$j_max;
    }
}

function token($code)
{
    $string = $code;
    $keyword=array();
    $keywords=array();
    $ngram=array();
    $tok = strtok($string, " # < > , ( ) ; { } [ ] \" : \n \t & %");
    while ($tok !== false) {
        //echo "Word=$tok<br/>";
        $tok = strtok(" # < > , ( ) ; { } [ ] \" : \n \t & %");
        $keyword[]=$tok;
    }
    $keywords=array_map('trim',$keyword);
    $k=0;
    for($i=0;$i<count($keywords);$i++){
       
        if(strcmp($keywords[$i],"include") ==0 || strcmp($keywords[$i],"define") ==0 || strcmp($keywords[$i],"stdio.h") ==0 ||
                strcmp($keywords[$i],"assert.h") ==0 || strcmp($keywords[$i],"complex.h") ==0 || strcmp($keywords[$i],"ctype.h") ==0 ||
                strcmp($keywords[$i],"errorno.h") ==0 || strcmp($keywords[$i],"fenv.h") ==0 || strcmp($keywords[$i],"float.h") ==0 ||
                strcmp($keywords[$i],"string.h") ==0 || strcmp($keywords[$i],"math.h") ==0 || strcmp($keywords[$i],"stdlib.h") ==0 ||
                strcmp($keywords[$i],"time.h") ==0 || strcmp($keywords[$i],"stddef.h") ==0){
           $ngram[$k]=1;
           //echo "<br/>data=".$keywords[$i]."=1";
           $k++;
        }
        elseif (strcmp($keywords[$i],"auto") ==0 || strcmp($keywords[$i],"double") ==0 || strcmp($keywords[$i],"int") ==0 || strcmp($keywords[$i],"struct") ==0 ||
                strcmp($keywords[$i],"break") ==0 || strcmp($keywords[$i],"else") ==0 || strcmp($keywords[$i],"long") ==0 || strcmp($keywords[$i],"switch") ==0 ||
                strcmp($keywords[$i],"case") ==0 || strcmp($keywords[$i],"enum") ==0 || strcmp($keywords[$i],"typedef") ==0 || strcmp($keywords[$i],"register") ==0 ||
                strcmp($keywords[$i],"char") ==0 || strcmp($keywords[$i],"extern") ==0 || strcmp($keywords[$i],"return") ==0 || strcmp($keywords[$i],"union") ==0 ||
                strcmp($keywords[$i],"const") ==0 || strcmp($keywords[$i],"float") ==0 || strcmp($keywords[$i],"short") ==0 || strcmp($keywords[$i],"unsigned") ==0 ||
                strcmp($keywords[$i],"continue") ==0 || strcmp($keywords[$i],"for") ==0 || strcmp($keywords[$i],"signed") ==0 || strcmp($keywords[$i],"void") ==0 ||
                strcmp($keywords[$i],"default") ==0 || strcmp($keywords[$i],"goto") ==0 || strcmp($keywords[$i],"sizeof") ==0 || strcmp($keywords[$i],"volatile") ==0 ||
                strcmp($keywords[$i],"do") ==0 || strcmp($keywords[$i],"if") ==0 || strcmp($keywords[$i],"static") ==0 || strcmp($keywords[$i],"while") ==0) {
            $ngram[$k]=2;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=2";
        }
        elseif (strcmp($keywords[$i],"+") ==0 || strcmp($keywords[$i],"-") ==0 || strcmp($keywords[$i],"*") ==0 || strcmp($keywords[$i],"/") ==0 || strcmp($keywords[$i],"%") ==0 ||
                strcmp($keywords[$i],"++") ==0 || strcmp($keywords[$i],"--") ==0 ||
                strcmp($keywords[$i],"=") ==0 || strcmp($keywords[$i],"+=") ==0 || strcmp($keywords[$i],"-=") ==0 || strcmp($keywords[$i],"*=") ==0 || strcmp($keywords[$i],"/=") ==0 ||
                strcmp($keywords[$i],"==") ==0 || strcmp($keywords[$i],">") ==0 || strcmp($keywords[$i],"<") ==0 || strcmp($keywords[$i],"<=") ==0 || strcmp($keywords[$i],">=") ==0 || strcmp($keywords[$i],"!=") ==0 ||
                strcmp($keywords[$i],"&&") ==0 || strcmp($keywords[$i],"||") ==0 || strcmp($keywords[$i],"!") ==0 ||
                strcmp($keywords[$i],"&") ==0 || strcmp($keywords[$i],"|") ==0 || strcmp($keywords[$i],"~") ==0 || strcmp($keywords[$i],"^") ==0 ||
                strcmp($keywords[$i],"<<") ==0 || strcmp($keywords[$i],">>") ==0 ||
                strcmp($keywords[$i],",") ==0 || strcmp($keywords[$i],"sizeof") ==0 || strcmp($keywords[$i],"?") ==0 || strcmp($keywords[$i],";") ==0) {
            $ngram[$k]=4;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=4";
        }
        elseif (strcmp($keywords[$i],"0") ==0 || strcmp($keywords[$i],"1") ==0 || strcmp($keywords[$i],"2") ==0 || strcmp($keywords[$i],"3") ==0 ||
                strcmp($keywords[$i],"4") ==0 || strcmp($keywords[$i],"5") ==0 || strcmp($keywords[$i],"6") ==0 || strcmp($keywords[$i],"7") ==0 ||
                strcmp($keywords[$i],"8") ==0 || strcmp($keywords[$i],"9") ==0) {
            $ngram[$k]=5;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=5";
        }
        elseif(strlen($keywords[$i])>0) {
            $ngram[$k]=3;
            $k++;
            //echo "<br/>data=".$keywords[$i]."=3";
        }
    }
    //print_r($ngram);
    return $ngram;
}

function compare($token1,$token2)
{
    $same=0;
    $distinct=0;
    $n1=0;
    foreach ($token1 as $tok){
        $n1=$n1+1;
    }
   // echo "Co=$n1";
//    for($i=0;count($token1)-3;$i=$i+4){
//        $flag=0;
//        for($j=0;count($token2)-3;$j++){
//            if($token1[$i]==$token2[$j] && $token1[$i+1]==$token2[$j+1] && $token1[$i+2]==$token2[$j+2] && $token1[$i+3]==$token2[$j+3]){
//                $same=$same+1;
//                $flag=1;
//                break;
//            }
//            if($flag==0){
//                $distinct=$distinct+1;
//            }
//        }
//    }
    //echo "count=".strlen($token1);
    //$jaccard=($distinct/$same)*100;
    //echo "jaccard=$jaccard";
    //return $jaccard;
}
?>