<!doctype html>
<html>
<head>
	<title>Put your title here</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="test.css" type="text/css" rel="stylesheet" />
</head>
<body>
	<div class="content">
		<div class="top_block title">
			<div class="content">
                            <h1 style="font-size: 50px;margin-left: 25px;">Maharashtra Institute Of Technology</h1>
			</div>
		</div>
		<div class="top_block imageBlock">
			<div class="content">
                            <script type="text/javascript">
                            </script>
                           <img src="Images/homepage1.png" style="margin-top: 20px; margin-left: 25px;"/>
				<div class="background buttonBlock">
				</div>
				<div class="right_block buttonBlock">
					<div class="content">
                                            <h1 style="font-size: 50px;margin-left: 25px;">Be a Better Programmer</h1>
                                            <a href="studentLogin.php" class="button">Student's Login</a>
                                            <a href="teacherLogin.php" class="button">Teacher's Login</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>